using System;
using System.Drawing;
using System.Windows.Forms;

class CalculatorForm : Form
{
    private TextBox textBox;
    private Calculator calculator;
    private double num1;
    private string operation;

    public CalculatorForm()
    {
        calculator = new Calculator();

        // TextBox for displaying results and inputs
        textBox = new TextBox
        {
            Location = new Point(15, 15),
            Width = 260,
            Height = 30,
            TextAlign = HorizontalAlignment.Right
        };

        // Create buttons for operations
        Button addButton = new Button
        {
            Text = "+",
            Location = new Point(15, 50),
            Width = 50,
            Height = 30
        };
        addButton.Click += (sender, e) => SetOperation("+");

        Button subtractButton = new Button
        {
            Text = "-",
            Location = new Point(70, 50),
            Width = 50,
            Height = 30
        };
        subtractButton.Click += (sender, e) => SetOperation("-");

        Button multiplyButton = new Button
        {
            Text = "*",
            Location = new Point(125, 50),
            Width = 50,
            Height = 30
        };
        multiplyButton.Click += (sender, e) => SetOperation("*");

        Button divideButton = new Button
        {
            Text = "/",
            Location = new Point(180, 50),
            Width = 50,
            Height = 30
        };
        divideButton.Click += (sender, e) => SetOperation("/");

        Button sqrtButton = new Button
        {
            Text = "√",
            Location = new Point(235, 50),
            Width = 50,
            Height = 30
        };
        sqrtButton.Click += (sender, e) => PerformSqrt();

        Button equalsButton = new Button
        {
            Text = "=",
            Location = new Point(15, 85),
            Width = 260,
            Height = 30
        };
        equalsButton.Click += (sender, e) => PerformCalculation();

        // Create numeric buttons
        for (int i = 1; i <= 9; i++)
        {
            Button numberButton = new Button
            {
                Text = i.ToString(),
                Location = new Point(15 + ((i - 1) % 3) * 55, 120 + ((i - 1) / 3) * 35),
                Width = 50,
                Height = 30
            };
            numberButton.Click += (sender, e) => textBox.Text += numberButton.Text;
            Controls.Add(numberButton);
        }

        // Create '0' button separately
        Button zeroButton = new Button
        {
            Text = "0",
            Location = new Point(15, 225),
            Width = 50,
            Height = 30
        };
        zeroButton.Click += (sender, e) => textBox.Text += "0";
        Controls.Add(zeroButton);

        // Create 'Clear' button
        Button clearButton = new Button
        {
            Text = "C",
            Location = new Point(180, 225),
            Width = 50,
            Height = 30
        };
        clearButton.Click += (sender, e) => textBox.Text = string.Empty;
        Controls.Add(clearButton);

        Controls.Add(textBox);
        Controls.Add(addButton);
        Controls.Add(subtractButton);
        Controls.Add(multiplyButton);
        Controls.Add(divideButton);
        Controls.Add(sqrtButton);
        Controls.Add(equalsButton);

        Text = "Calculator";
        Size = new Size(300, 300);
    }

    // Set operation and store the first number
    private void SetOperation(string op)
    {
        if (double.TryParse(textBox.Text, out num1))
        {
            operation = op;
            textBox.Text = string.Empty; // Clear text for second operand
        }
        else
        {
            MessageBox.Show("Please enter a valid number.");
        }
    }

    // Perform calculation when '=' is clicked
    private void PerformCalculation()
    {
        if (operation != null && double.TryParse(textBox.Text, out double num2))
        {
            double result = calculator.Calculate(num1, num2, operation);
            textBox.Text = result.ToString();
            operation = null; // Reset operation
        }
        else
        {
            MessageBox.Show("Please enter a valid number and select an operation.");
        }
    }

    // Perform square root calculation
    private void PerformSqrt()
    {
        if (double.TryParse(textBox.Text, out double num))
        {
            double result = calculator.Calculate(num, 0, "√");
            textBox.Text = result.ToString();
        }
        else
        {
            MessageBox.Show("Please enter a valid number.");
        }
    }
}

// A basic Calculator class
public class Calculator
{
    public double Calculate(double num1, double num2, string operation)
    {
        switch (operation)
        {
            case "+":
                return num1 + num2;
            case "-":
                return num1 - num2;
            case "*":
                return num1 * num2;
            case "/":
                return num2 != 0 ? num1 / num2 : throw new DivideByZeroException("Cannot divide by zero.");
            case "√":
                return num1 >= 0 ? Math.Sqrt(num1) : throw new ArgumentException("Cannot take the square root of a negative number.");
            default:
                throw new InvalidOperationException("Unknown operation.");
        }
    }
}
